//Function returning value and taking arguments(or parameters)
//Logic:Function definition, Input,Output:main() function
#include<stdio.h>
int add(int,int); //Function declaration
int main()
{
int a,b,result;
printf("\n Enter two numbers:");
scanf("%d%d",&a,&b);
result=add(a,b); //Function calling //a, b are actual arguments
printf("\n Sum is:%d",result);
return 0;
}
//Function definition
int add(int x,int y) //x and y are formal arguments
{
int sum;
sum=x+y;
return sum;
}
