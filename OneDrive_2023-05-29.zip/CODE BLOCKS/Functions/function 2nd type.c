//Function returning a value but taking no arguments(or parameters)
//Input and logic-->Inside function definition and Output--->main() function
#include<stdio.h>
int add(); //Function declaration
int main()
{
int result;
result=add(); //Function calling
printf("\n Sum is:%d",result);
return 0;
}
//Function definition
int add()
{
int a,b,sum;
printf("\n Enter two numbers:");
scanf("%d%d",&a,&b);
sum=a+b;
return sum;
}
