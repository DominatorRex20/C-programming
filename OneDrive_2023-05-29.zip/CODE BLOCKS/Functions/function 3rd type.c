//Function not returning the value but taking arguments(or parameters)
//Input-->main() function, Logic and Output--->Function definition
//Call by value[Passing the original values to the formal arguments, where formal arguments will act as copies of original values
//Whatever changes are made by the function definition to the formal arguments, those changes are not visible to the original values
//It can consume more space and time
//Original values are never modified
#include<stdio.h>
void add(int,int); //Function declaration
int main()
{
int a,b;
printf("\n Enter two numbers:");
scanf("%d%d",&a,&b);
add(a,b); //Function calling //a, b are actual arguments
return 0;
}
//Function definition
void add(int x,int y) //x and y are formal arguments
{
int sum;
sum=x+y;
printf("\n Sum of two numbers is:%d",sum);
}
