//Default values in case of calloc()
#include<stdio.h>
#include<stdlib.h>
int main()
{
int *ptr,n,i;
printf("\nEnter value of n:");
scanf("%d",&n);
ptr=(int*)calloc(n,sizeof(int));
if(ptr==NULL)
{
printf("\nMemory allocation failure");
exit(1);//Abnormal termination
}
else
{
printf("\nMemory allocation was successful and address in ptr is:%u",ptr);
printf("\nDefault values are:");
for(i=0;i<n;i++)
{
printf("\n%d",*(ptr+i));//Default initial values are: Zeroes
}
}
return 0;
}
