//Reading and displaying group of n integer values using malloc()[DMA]
#include<stdio.h>
#include<stdlib.h>
int main()
{
int *ptr,n,i;
printf("\nEnter value of n:");
scanf("%d",&n);
ptr=(int*)malloc(n*sizeof(int));
if(ptr==NULL)
{
printf("\nMemory allocation failure");
exit(1);//Abnormal termination
}
else
{
printf("\nMemory allocation was successful and address in ptr is:%u",ptr);
printf("\nEnter array elements:");
for(i=0;i<n;i++)
{
scanf("%d",ptr+i);//i+ptr, &ptr[i],&i[ptr]
}
printf("\n Values stored in the memory locations are:");
for(i=0;i<n;i++)
{
printf("\n%d",*(ptr+i));//*(i+ptr),ptr[i],i[ptr]
}
}
return 0;
}
