#include<stdio.h>
#include<math.h>
int main()
{
int m[12][27],s=0,n[12];
double k=0.0;
for(int i=1;i<=12;i++)
{
for(int j=1;j<=27;j++)
{
printf("\n Enter temperature for %d  day of %d  month  ",j,i);
scanf("%lf", &k);
m[i-1][j-1]=round(k);
}
}
for(int i=0;i<12;i++)
{
for(int j=0;j<27;j++)
{
    s=m[i][j]+s;
}
k=s/12.0;
printf("\n Average temperature of %d month : %lf", (i+1), k);
n[i]=k;
s=0;
}
for(int i=0;i<12;i++)
{
    s=s+n[i];
}
k=s/12.0;
printf("\n Average of 12 months: %lf", k);


for(int i=0;i<12;i++)
{
    s=m[i][0];
for(int j=1;j<27;j++)
{
    if(m[i][j]>s)
        s=m[i][j];
}
printf("\n Max of %d month : %d", (i+1) , s);
n[i]=s;
s=0;
}
s=n[0];
for(int i=1;i<12;i++)
{
    if(n[i]>s)
       s=n[i];
}
printf("\n Max of 12 months: %d", s);

for(int i=0;i<12;i++)
{
    s=m[i][0];
for(int j=1;j<27;j++)
{
    if(m[i][j]<s)
        s=m[i][j];
}
printf("\n Min of %d month : %d", (i+1), s);
n[i]=s;
s=0;
}
s=n[0];
for(int i=1;i<12;i++)
{
    if(n[i]<s)
       s=n[i];
}
printf("\n Min of 12 months: %d", s);
return 0;
}
