//Reading and displaying array elements(2D)
#include<stdio.h>
int main()
{
int a[3][2];
int i,j;
printf("\nEnter array elements:");
for(i=0;i<3;i++)
{
for(j=0;j<2;j++)
{
scanf("%d",&a[i][j]);
}
}
printf("\nEntered array elements are:");
for(i=0;i<3;i++)
{
printf("\n");
for(j=0;j<2;j++)
{
printf("%d ",a[i][j]);
}
}
return 0;
}

2:21 PM
