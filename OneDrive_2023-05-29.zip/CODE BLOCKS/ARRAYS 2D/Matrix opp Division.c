//Addition of 2 matrices
#include<stdio.h>
int main()
{
int a[100][100],b[100][100],c[100][100];
int i,j;
int rowsize,colsize;
printf("\nEnter row and column size:");
scanf("%d%d",&rowsize,&colsize);
printf("\nEnter elements of 1st matrix:");
for(i=0;i<rowsize;i++)
{
for(j=0;j<colsize;j++)
{
scanf("%d",&a[i][j]);
}
}
printf("\nEnter elements of 2nd matrix:");
for(i=0;i<rowsize;i++)
{
for(j=0;j<colsize;j++)
{
scanf("%d",&b[i][j]);
}
}
for(i=0;i<rowsize;i++)
{
for(j=0;j<colsize;j++)
{
c[i][j]=a[i][j]/nb[i][j];
}
}
printf("\nResultant matrix is:");
for(i=0;i<rowsize;i++)
{
printf("\n");
for(j=0;j<colsize;j++)
{
printf("%d ",c[i][j]);
}
}
return 0;
}
