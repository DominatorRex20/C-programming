//WAP to find the row-wise sum of 2D array[Row wise sum is displayed]
#include<stdio.h>
int main()
{
int a[3][3],sum=0;
int i,j;
printf("\nEnter array elements:");
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
scanf("%d",&a[i][j]);
}
}
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
sum=sum+a[i][j];
}
printf("\nSum of elements of row no:%d is:%d",i+1,sum);
sum=0;
}
return 0;
}
