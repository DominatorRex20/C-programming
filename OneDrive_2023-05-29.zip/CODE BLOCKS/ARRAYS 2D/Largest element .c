//WAP to display largest element from the 2D array
#include<stdio.h>
int main()
{
int a[3][3],largest;
int i,j;
printf("\nEnter array elements:");
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
scanf("%d",&a[i][j]);
}
}
largest=a[0][0];
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
if(a[i][j]>largest)
{
largest=a[i][j];
}
}
}
printf("\nLargest element is:%d",largest);
return 0;
}
