//WAP to find the sum of all elements of 2D array
#include<stdio.h>
int main()
{
int a[3][3],sum=0;
int i,j;
printf("\nEnter array elements:");
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
scanf("%d",&a[i][j]);
}
}
for(i=0;i<3;i++)
{
printf("\n");
for(j=0;j<3;j++)
{
sum=sum+a[i][j];
}
}
printf("\nSum is:%d",sum);
return 0;
}

