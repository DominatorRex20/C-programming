//By reference[Implementing linear search by passing array to function]
#include<stdio.h>
int linear(int[],int);
int main()
{
int a[10],i,n,result;
printf("\nEnter array elements:");
for(i=0;i<10;i++)
{
scanf("%d",&a[i]);
}
n=sizeof(a)/sizeof(int);
result=linear(a,n);//Actual arguments
if(result!=-1)
{
printf("\nElement is found at index:%d and exact location:%d",result,result+1);
}
else
{
printf("\nElement not found");
}
return 0;
}
int linear(int x[],int y)
{
int i,loc=-1,key;
printf("\nEnter element to search:");
scanf("%d",&key);
for(i=0;i<y;i++)
{
if(x[i]==key)
{
loc=i;
break;
}
}
return loc;
}


