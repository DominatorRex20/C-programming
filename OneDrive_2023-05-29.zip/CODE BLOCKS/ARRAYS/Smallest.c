//WAP to display smallest element from an array(ID)
#include<stdio.h>
int main()
{
int a[5],i,smallest;
printf("\nEnter array elements:");
for(i=0;i<5;i++)
{
scanf("%d",&a[i]);
}
smallest=a[0];
for(i=1;i<5;i++)
{
if(a[i]<smallest)
{
smallest=a[i];
}
}
printf("\nSmallest element is:%d",smallest);
return 0;
}


