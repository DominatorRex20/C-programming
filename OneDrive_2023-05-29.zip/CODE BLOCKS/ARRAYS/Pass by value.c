//By value
#include<stdio.h>
void dummy(int);
int main()
{
int a[10],i,n,result;
printf("\nEnter array elements:");
for(i=0;i<10;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<10;i++)
{
dummy(a[i]);
}
printf("\n Array elements after function call are:");
for(i=0;i<10;i++)
{
printf("\n%d",a[i]);
}
return 0;
}
void dummy(int x)
{
x=x+2;
printf("\n%d",x);
}
