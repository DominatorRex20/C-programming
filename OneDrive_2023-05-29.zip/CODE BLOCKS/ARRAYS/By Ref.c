//By reference
#include<stdio.h>
void byref(int[],int);
int main()
{
int a[10],i,n;
printf("\nEnter array elements:");
for(i=0;i<10;i++)
{
scanf("%d",&a[i]);
}
n=sizeof(a)/sizeof(int);
byref(a,n);//Actual arguments
printf("\nUpdated array elements are:");
for(i=0;i<10;i++)
{
printf("\n%d",a[i]);
}
return 0;
}
void byref(int x[],int y)//Formal arguments
{
int i;
for(i=0;i<y;i++)
{
x[i]=x[i]+2;
}
}
