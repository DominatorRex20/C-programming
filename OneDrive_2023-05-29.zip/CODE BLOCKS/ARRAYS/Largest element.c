//WAP to display largest element from an array(ID)
#include<stdio.h>
int main()
{
int a[5],i,largest;
printf("\nEnter array elements:");
for(i=0;i<5;i++)
{
scanf("%d",&a[i]);
}
largest=a[0];
for(i=1;i<5;i++)
{
if(a[i]>largest)
{
largest=a[i];
}
}
printf("\nLargest element is:%d",largest);
return 0;
}
