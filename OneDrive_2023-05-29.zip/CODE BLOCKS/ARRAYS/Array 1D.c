//WAP to read and display elements of array(1D)
#include<stdio.h>
int main()
{
int a[5],i;
printf("\nEnter array elements:");
for(i=0;i<5;i++)
{
scanf("%d",&a[i]);
}
printf("\nArray elements are:");
for(i=0;i<5;i++)
{
printf("\n%d",a[i]);
}
return 0;
}

