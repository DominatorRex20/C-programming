#include<stdio.h>
int main()
{
int a,b,c,largest;
printf("\nEnter values of a ,b and c:");
scanf("%d%d%d",&a,&b,&c);
largest=(a>b>c)?a:b:c;
printf("\nLargest number is:%d",largest);
return 0;
}
