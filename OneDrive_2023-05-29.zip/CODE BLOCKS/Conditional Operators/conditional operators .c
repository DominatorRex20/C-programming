#include<stdio.h>
int main() {

int 12_thmarks;
printf("\nEnter 12th marks");
scanf("%d",&12th marks);
12th marks>=60?("\nEligible"):(\nNoteligible);

intjee marks;
printf("Enter jee marks");
scanf("%d",&jee marks);
jee marks>=200?("\nEligible"):(\nNoteligible);
return 0;
}
